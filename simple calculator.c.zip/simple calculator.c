#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main(){
  void Calculator(){
	int i;
  printf("Choose the operation:\n");
  printf("1.Addition\n");
  printf("2.Subtraction\n");
  printf("3.Multiplication\n");
  printf("4.Division\n");
  printf("Type q to close the programm\n");
	scanf("%d",&i);
	double FirstNumber;
	double SecondNumber;
	double Result;
  char MyChar;
  MyChar = getchar();
  if (MyChar == 'q'){
    _Exit (EXIT_SUCCESS);
  }
  if (i >= 1 && i <=4){
    printf("Enter the first number: ");
    scanf("%lf",&FirstNumber);
    printf("Enter the second number: ");
    scanf("%lf",&SecondNumber);
    switch(i){
		    case 1: ;
			    Result = FirstNumber + SecondNumber;
			    break;
		    case 2: ;
			    Result = FirstNumber - SecondNumber;
			    break;
		    case 3: ;
			    Result = FirstNumber * SecondNumber;
			    break;
		    case 4: ;
			    Result = FirstNumber / SecondNumber;
			    break;
    }
    printf("%lf\n",Result);
  }
  else {
    printf("Choose in range 1-4\n");
    Calculator();
  }
  sleep(1);
  Calculator();
  }
  Calculator();
	return 0;
}
